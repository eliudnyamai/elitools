<?php
header('Location:../');